import pygame
import keyboard

# /\ imports modules

#initialzes pygame
pygame.init()

#defines world tilemap (i tried to make a donut)
world = [[1, 1, 1, 1, 1],
[1, 2, 2, 2, 1],
[1, 2, 1, 2, 1],
[1, 2, 2, 2, 1],
[1, 1, 1, 1, 1]]

#imports textures
grass = pygame.image.load("grass.png")
grass = pygame.transform.scale(grass, (50, 50))

#resizes textures to 50x50 so they fit
dirt = pygame.image.load("dirt.jpg")
dirt = pygame.transform.scale(dirt, (50, 50))

scrollx = 0
scrolly = 0

fps = 30

#defines clok and window
clock = pygame.time.Clock()
game = pygame.display.set_mode((500, 500))
pygame.display.set_caption("Tiles")

#infinite loop
active = True
while active:
    #stops loop if window is closed
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            active = False
    
    #fills background with black
    game.fill((0, 0, 0))

    #changes scroll values based on keys pressed
    if keyboard.is_pressed("w"):
        scrolly = scrolly - 10

    if keyboard.is_pressed("a"):
        scrollx = scrollx - 10

    if keyboard.is_pressed("s"):
        scrolly = scrolly + 10

    if keyboard.is_pressed("d"):
        scrollx = scrollx + 10

    #loops through world list and placed tiles individually
    colnom = 0
    for column in world:
        colnom += 1
        rownom = 0
        for row in column:
            rownom += 1

            if row == 1:
                texture = grass
            elif row == 2:
                texture = dirt

            game.blit(texture, ((colnom * 50) - scrollx, (rownom * 50) - scrolly))

    #updates display
    pygame.display.update()
    clock.tick(fps)